import java.util.Vector;
import java.util.EmptyStackException;

class InheritanceVersusComposition {
    public static void main( String[] args ) {
        demoStackViaInheritanceFromJavaUtilVector();
        //demoStackViaCompositionFromJavaUtilVector();
    }



    private static void demoStackViaInheritanceFromJavaUtilVector() {
        System.out.printf( "\nCreating a java.util.Stack, which \"is a\" java.util.Vector\n" );

        java.util.Stack<Integer> stack = new java.util.Stack<Integer>();
        stack.push( 1 );
        stack.push( 2 );
        stack.push( 3 );
        stack.push( 4 );
        System.out.printf( "\nAfter stack.push(1), stack.push(2), stack.push(3), stack.push(4), stack is %s\n", stack );

        // The problem with implementing a Stack class using inheritance is that the class
        // inherits all of its parent's methods, which include methods like add() that provide
        // capabilities that should not be allowed on a Stack.
        stack.add( 2, 99 );
        System.out.printf( "\nAfter bogus stack.add( 2, 99 ), stack is %s\n\n", stack );

        while( !stack.empty() ) {
            System.out.printf( "stack.pop() returned %d\n", stack.pop() );
        }
    }


    private static void demoStackViaCompositionFromJavaUtilVector() {
        System.out.printf( "\n\n\nCreating a StackViaComposition stack, which \"has a\" java.util.Vector\n" );

        StackViaComposition stack = new StackViaComposition();
        stack.push( 1 );
        stack.push( 2 );
        stack.push( 3 );
        stack.push( 4 );
        System.out.printf( "\nAfter stack.push(1), stack.push(2), stack.push(3), stack.push(4), stack is %s\n\n", stack );

        // Because a StackViaComposition object doesn't extend java.util.Vector, it doesn't have an add method.
        //stack.add( 2, 99 );
        //System.out.printf( "\nAfter bogus stack.add( 2, 99 ), stack is %s\n\n", stack );

        while( !stack.empty() ) {
            System.out.printf( "stack.pop() returned %d\n", stack.pop() );
        }
    }


}


// This class *uses* a Vector, but it's not the case that this class "is a" Vector.
// This class's push() actually adds items to the *beginning* of the vector.
// This class's pop() actually removes items from the *beginning* of the vector.
class StackViaComposition {
    private Vector<Object> theData = new Vector<Object>();

    public void    push( Object obj ) { theData.add( 0, obj ); }
    public Object  pop()              { return theData.remove( 0 ); }
    public boolean empty()            { return theData.size() == 0; }
    public String  toString()         { return theData.toString(); }
}
