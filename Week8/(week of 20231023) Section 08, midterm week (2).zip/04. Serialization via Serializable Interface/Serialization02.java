// This version serializes an array of Person objects.

import java.util.Arrays;
import java.util.Scanner;
import java.io.Serializable;
import java.io.ObjectOutputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.FileInputStream;
import java.io.IOException;



public class Serialization02 {

    final static String FILENAME = "foo.ser";

    public static void main(String [] args) {
        System.out.println( "Serialization02" );
        Scanner keyboard = new Scanner(System.in);
        char response;
        boolean notDone;
        Person [] persons;

        do {
            System.out.printf("\nEnter w to write %s, or r to read %s: ", FILENAME, FILENAME);
            response = keyboard.next().toLowerCase().charAt( 0 );
            notDone = response != 'q';

            switch( response ) {
                case 'w':
                    persons = new Person[2];
                    persons[0] = new Person("David", "male", 59, 72);
                    persons[1] = new Person("Janice", "female", 61, 68);
                    write( persons, FILENAME );
                    break;

                case 'r':
                    persons = read( FILENAME );
                    break;

                case 'q':
                    break;

                default:
                    System.out.println("\nUnrecognized response.\n");
                    break;
            }
        } while( notDone );
    }

    static void write( Person[] persons, String filename ) {
        ObjectOutputStream out = null;
        try {
            out = new ObjectOutputStream( new FileOutputStream(filename) );
            out.writeObject(persons);
            out.close();
            System.out.printf("\nWrote %s to %s\n\n", Arrays.toString(persons), filename);
        }
        catch(IOException e) {
          e.printStackTrace();
        }
    }

    static Person[] read( String filename ) {
        Person[] persons = null;
        ObjectInputStream in = null;
        try {
            in = new ObjectInputStream( new FileInputStream(filename) );
            persons = (Person[])in.readObject();
            in.close();
            System.out.printf("\nRead %s from %s\n\n", Arrays.toString(persons), filename);
        }
        catch(IOException e) {
            e.printStackTrace();
        }
        catch(ClassNotFoundException e) {
            e.printStackTrace();
        }
        return persons;
    }
}
