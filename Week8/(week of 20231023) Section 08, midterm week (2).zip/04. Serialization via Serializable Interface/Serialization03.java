// This version serializes an ArrayList Person objects.

// Because we try to cast the object returned by readObject() to a value whose type is generic (ArraList<Person>),
// it generates a compiler warning (although the resulting .class file executes ok):
//     [Serialization via Serializable Interface]javac -Xlint:unchecked Serialization03.java
//     Serialization03.java:86: warning: [unchecked] unchecked cast
//                     persons = (ArrayList<Person>)in.readObject();
//                                                               ^
//       required: ArrayList<Person>
//       found:    Object
//     1 warning


import java.util.ArrayList;
import java.util.Scanner;
import java.io.Serializable;
import java.io.ObjectOutputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.FileInputStream;
import java.io.IOException;



public class Serialization03 {

    final static String FILENAME = "foo.ser";

    public static void main(String [] args) {
        System.out.println( "Serialization03" );
        Scanner keyboard = new Scanner(System.in);
        char response;
        boolean notDone;
        ArrayList<Person> persons;

        do {
            System.out.printf("\nEnter w to write %s, or r to read %s: ", FILENAME, FILENAME);
            response = keyboard.next().toLowerCase().charAt( 0 );
            notDone = response != 'q';

            switch( response ) {
                case 'w':
                    persons = new ArrayList<Person>();
                    persons.add( new Person("David", "male", 59, 72) );
                    persons.add( new Person("Janice", "female", 61, 68) );
                    write( persons, FILENAME );
                    break;

                case 'r':
                    persons = read( FILENAME );
                    break;

                case 'q':
                    break;

                default:
                    System.out.println("\nUnrecognized response.\n");
                    break;
            }
        } while( notDone );
    }

    static void write( ArrayList<Person> persons, String filename ) {
        FileOutputStream fos = null;
        ObjectOutputStream out = null;
        try {
            fos = new FileOutputStream(filename);
            out = new ObjectOutputStream(fos);
            out.writeObject(persons);
            out.close();
            System.out.printf("\nWrote %s to %s\n\n", persons, filename);
        }
        catch(IOException e) {
          e.printStackTrace();
        }
    }

    static ArrayList<Person> read( String filename ) {
        ArrayList<Person> persons = null;
        FileInputStream fis = null;
        ObjectInputStream in = null;
        try {
            fis = new FileInputStream(filename);
            in = new ObjectInputStream(fis);
            persons = (ArrayList<Person>)in.readObject();
            System.out.printf("\nRead %s from %s\n\n", persons, filename);
            in.close();
        }
        catch(IOException e) {
            e.printStackTrace();
        }
        catch(ClassNotFoundException e) {
            e.printStackTrace();
        }
        return persons;
    }
}
