import java.io.Serializable;
import java.util.ArrayList;

class PersonPlus extends Person implements Serializable {

    // transient modifier marks the item as non-serializable
    // However, since the constructor doesn't run when deserializing objects, its deserialized value is 0, not 99
    transient int dontSerializeMe;

    public PersonPlus() { this( "", "", 0, 0 ); }
    public PersonPlus( String name, String gender, int age, int height ) {
        super( name, gender, age, height );
        this.setNonSerializableState();
    }

    protected void setNonSerializableState() {
        this.dontSerializeMe = 99;
    }

    public String toString() {
        return String.format( "%s (%d)", super.toString(), this.dontSerializeMe );
    }
}



class PersonsPlus  implements Serializable {
    private ArrayList<PersonPlus> persons = new ArrayList<PersonPlus>();

    public int size() {
        return persons.size();
    }

    public void add(PersonPlus person) {
        persons.add(person);
    }

    public PersonPlus getPerson(int i) {
        return persons.get(i);
    }

    public String toString() {
        return persons.toString();
    }
}
