import java.io.Serializable;
import java.util.ArrayList;
import java.io.ObjectInputStream;
import java.io.IOException;

class PersonPlusPlus extends PersonPlus implements Serializable {

    public PersonPlusPlus() {}
    public PersonPlusPlus( String name, String gender, int age, int height ) {
        super( name, gender, age, height );
    }

    private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
        in.defaultReadObject();
        this.setNonSerializableState();
    }
}



class PersonsPlusPlus  implements Serializable {
    private ArrayList<PersonPlusPlus> persons = new ArrayList<PersonPlusPlus>();

    public int size() {
        return persons.size();
    }

    public void add(PersonPlusPlus person) {
        persons.add(person);
    }

    public PersonPlusPlus getPerson(int i) {
        return persons.get(i);
    }

    public String toString() {
        return persons.toString();
    }
}
