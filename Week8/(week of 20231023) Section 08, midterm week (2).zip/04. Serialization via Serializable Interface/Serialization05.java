// This version serializes a PersonsPlus object that "has a" ArrayList of PersonPlus objects whose instance variables are *not* all serializable.
// Such variables might be, e.g., open file handles. See PersonPlus.java

// PersonPlus's constructor does not run when a PersonPlus object is deserialized, so the non-serialized
// instance variables are not initialized.

import java.util.Scanner;
import java.io.Serializable;
import java.io.ObjectOutputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.FileInputStream;
import java.io.IOException;



public class Serialization05 {

    final static String FILENAME = "foo.ser";

    public static void main(String [] args) {
        System.out.println( "Serialization05" );
        Scanner keyboard = new Scanner(System.in);
        char response;
        boolean notDone;
        PersonsPlus persons;

        do {
            System.out.printf("\nEnter w to write %s, or r to read %s: ", FILENAME, FILENAME);
            response = keyboard.next().toLowerCase().charAt( 0 );
            notDone = response != 'q';

            switch( response ) {
                case 'w':
                    persons = new PersonsPlus();
                    persons.add( new PersonPlus("David", "male", 59, 72) );
                    persons.add( new PersonPlus("Janice", "female", 61, 68) );
                    write( persons, FILENAME );
                    System.out.printf("\nWrote %s to %s\n\n", persons, FILENAME);
                    break;

                case 'r':
                    persons = read( FILENAME );
                    System.out.printf("\nRead %s from %s\n\n", persons, FILENAME);
                    break;

                case 'q':
                    break;

                default:
                    System.out.println("\nUnrecognized response.\n");
                    break;
            }
        } while( notDone );
    }

    static void write( PersonsPlus persons, String filename ) {
        FileOutputStream fos = null;
        ObjectOutputStream out = null;
        try {
            fos = new FileOutputStream(filename);
            out = new ObjectOutputStream(fos);
            out.writeObject(persons);
            out.close();
        }
        catch(IOException e) {
          e.printStackTrace();
        }
    }

    static PersonsPlus read( String filename ) {
        PersonsPlus persons = null;
        FileInputStream fis = null;
        ObjectInputStream in = null;
        try {
            fis = new FileInputStream(filename);
            in = new ObjectInputStream(fis);
            persons = (PersonsPlus)in.readObject();
            in.close();
        }
        catch(IOException e) {
            e.printStackTrace();
        }
        catch(ClassNotFoundException e) {
            e.printStackTrace();
        }
        return persons;
    }
}
