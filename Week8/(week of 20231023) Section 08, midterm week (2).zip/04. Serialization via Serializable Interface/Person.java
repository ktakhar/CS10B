import java.io.Serializable;
import java.util.ArrayList;

class Person   implements Serializable {
//class Person {
    private String name, gender;
    private int age, height;

    public Person() { this( "", "", 0, 0 ); }
    public Person( String name, String gender, int age, int height ) {
        this.name = name;
        this.gender = gender;
        this.age = age;
        this.height = height;
    }

    public String toString() {
        return String.format("%s %s %d %d", this.name, this.gender, this.age, this.height);
    }
}



class Persons  implements Serializable {
    private ArrayList<Person> persons = new ArrayList<Person>();

    public int size() {
        return persons.size();
    }

    public void add(Person person) {
        persons.add(person);
    }

    public Person getPerson(int i) {
        return persons.get(i);
    }

    public String toString() {
        return persons.toString();
    }
}
