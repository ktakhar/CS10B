// This version serializes several individual Person objects.

import java.util.Arrays;
import java.util.Scanner;
import java.io.Serializable;
import java.io.ObjectOutputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.FileInputStream;
import java.io.IOException;



public class Serialization01 {

    final static String FILENAME = "foo.ser";

    public static void main(String [] args) {
        System.out.println( "Serialization01" );
        Scanner keyboard = new Scanner(System.in);
        char response;
        boolean notDone;
        Person person1, person2;

        do {
            System.out.printf("\nEnter w to write %s, or r to read %s: ", FILENAME, FILENAME);
            response = keyboard.next().toLowerCase().charAt( 0 );
            notDone = response != 'q';

            switch( response ) {
                case 'w':
                    person1 = new Person("David", "male", 59, 72);
                    person2 = new Person("Janice", "female", 61, 68);
                    try {
                        ObjectOutputStream out = new ObjectOutputStream( new FileOutputStream( FILENAME ) );
                        out.writeObject(person1);
                        System.out.printf("\nWrote %s to %s", person1, FILENAME);
                        out.writeObject(person2);
                        System.out.printf("\nWrote %s to %s\n\n", person2, FILENAME);
                        out.close();
                    }
                    catch(IOException e) {
                      e.printStackTrace();
                    }
                    break;

                case 'r':
                    try {
                        //FileInputStream fis = new FileInputStream(FILENAME);
                        ObjectInputStream in = new ObjectInputStream(new FileInputStream(FILENAME));
                        person1 = (Person)in.readObject();
                        System.out.printf("\nRead %s from %s", person1, FILENAME);
                        person2 = (Person)in.readObject();
                        System.out.printf("\nRead %s from %s\n", person2, FILENAME);
                        in.close();
                    }
                    catch(IOException e) {
                        e.printStackTrace();
                    }
                    catch(ClassNotFoundException e) {
                        e.printStackTrace();
                    }
                    break;

                case 'q':
                    break;

                default:
                    System.out.println("\nUnrecognized response.\n");
                    break;
            }
        } while( notDone );
    }
}
