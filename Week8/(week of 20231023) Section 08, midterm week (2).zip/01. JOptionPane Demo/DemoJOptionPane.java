// Demonstrate the JOptionPane class.
// JOptionPane makes it easy to pop up a standard dialog box that
// prompts users for a value or informs them of something.

import javax.swing.JOptionPane;

public class DemoJOptionPane {

    // Method Name         Description
    // -----------------   -----------------------------------------------
    // showInputDialog     Prompt for some input.
    // showMessageDialog   Tell the user about something that has happened.
    // showConfirmDialog   Asks a confirming question, like yes/no/cancel.

    public static void main(String [] args) {
        String something, choice;
        int    messageType =
                   //JOptionPane.ERROR_MESSAGE,
                   //JOptionPane.INFORMATION_MESSAGE,
                   //JOptionPane.WARNING_MESSAGE,
                   //JOptionPane.QUESTION_MESSAGE,
                   JOptionPane.PLAIN_MESSAGE,

               optionType =
                   //JOptionPane.DEFAULT_OPTION;
                   JOptionPane.YES_NO_OPTION;
                   //JOptionPane.YES_NO_CANCEL_OPTION;
                   //JOptionPane.OK_CANCEL_OPTION;

        // 1. Get user input.
        something = String.format( "You typed \"%s\"", JOptionPane.showInputDialog( "Please type something" ) );

        // 2. Display a popup containing the user's input.
        JOptionPane.showMessageDialog( null, something, "DemoJOptionPane", messageType );

        // 3. Offer user a choice
        int choiceInt = JOptionPane.showConfirmDialog( null, "choose one", "choose one", optionType );
        switch( choiceInt ) {
            case JOptionPane.YES_OPTION:    choice="Yes";              break;
            case JOptionPane.NO_OPTION:     choice="No";               break;
            case JOptionPane.CANCEL_OPTION: choice="Cancel";           break;
            case JOptionPane.CLOSED_OPTION: choice="the close button"; break;
            default:                        choice="Unknown";          break;
        }
        JOptionPane.showMessageDialog( null, "You clicked "+choice, "DemoJOptionPane", JOptionPane.INFORMATION_MESSAGE );
    }
}
