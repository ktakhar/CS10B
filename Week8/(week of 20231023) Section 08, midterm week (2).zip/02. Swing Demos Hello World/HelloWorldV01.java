// HelloWorldV01: Minimal GUI program.

import javax.swing.*;

public class HelloWorldV01 {

    private static final String TITLE="Hello World 01";

    public static void main(String [] args) {

        // Construct a window
        JFrame myWindow = new JFrame(TITLE);

        // Construct a label widget
        JLabel myLabel = new JLabel(TITLE);

        // Add the label widget to the window.
        myWindow.add(myLabel);

        // Make it visible.
        myWindow.setVisible(true);

        // Nothing else for main() to do.
        System.out.println("Nothing else for main() to do");
    }
}
