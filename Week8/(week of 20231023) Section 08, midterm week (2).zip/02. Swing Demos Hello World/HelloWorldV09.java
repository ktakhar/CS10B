// HelloWorldV09: Use a fancier GridLayout with nesting.

import javax.swing.*;
import java.awt.*;

public class HelloWorldV09 {

    private static final String TITLE="Hello World 09";

    public static void main(String [] args) {

        // Construct the window
        MyWindow myWindow = new MyWindow(TITLE);

        // Make it visible
        myWindow.setVisible(true);

        // Nothing else for main() to do.
        System.out.println("Nothing else for main() to do");
    }
}



// "extends JFrame" is like saying "I'm a window."
class MyWindow extends JFrame {

    private static final int WIDTH=300, HEIGHT=200;
    private JLabel myLabel1 = new JLabel("Label one"),    // row 1, column 1
                   myLabel2 = new JLabel("Label two"),    // row 1, column 2
                   myLabel3 = new JLabel("Label three"),  // row 1, column 3
                   myLabel4 = new JLabel("Label four"),   // row 2, column 1
                // We'll use a JPanel in place of myLabel5
                // myLabel5 = new JLabel("Label five"),   // row 2, column 2
                   myLabel6 = new JLabel("Label six"),    // row 2, column 3

                   myLabelNorth = new JLabel("North"),    // row 2, column 2
                   myLabelSouth = new JLabel("South"),    // row 2, column 2
                   myLabelEast = new JLabel("East"),      // row 2, column 2
                   myLabelWest = new JLabel("West"),      // row 2, column 2
                   myLabelCenter = new JLabel("Center");  // row 2, column 2
    private JPanel myPanel = new JPanel();

    // The actual creation of the window happens in the class's constructor
    public MyWindow(String title) {

        this.setTitle(title);

        // Attach a layout manager.
        this.setLayout(new GridLayout(2, 3)); // two rows, three columns

        // We'll substitute a more complex Jpanel in place of myLabel5. The JPanel will use a BorderLayout.
        // Each region will contain a descriptive label.
        myPanel.setLayout(new BorderLayout());
        myPanel.add(myLabelNorth, BorderLayout.NORTH);
        myPanel.add(myLabelSouth, BorderLayout.SOUTH);
        myPanel.add(myLabelEast, BorderLayout.EAST);
        myPanel.add(myLabelWest, BorderLayout.WEST);
        myPanel.add(myLabelCenter, BorderLayout.CENTER);
        myPanel.setBorder(BorderFactory.createLineBorder(Color.black));

        // Add the widgets to the window
        this.add(myLabel1);  // row 1, column 1
        this.add(myLabel2);  // row 1, column 2
        this.add(myLabel3);  // row 1, column 3
        this.add(myLabel4);  // row 2, column 1
        this.add(myPanel);   // row 2, column 2 (Note that this grid cell gets a JPanel widget)
        this.add(myLabel6);  // row 2, column 3

        // Resize the window.
        this.setSize(WIDTH, HEIGHT);

        // Center the windows
        this.setLocationRelativeTo(null); // Centers the window

        // Tell the jvm to kill the program when the window closes.
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Let's see which layout Manager is being used.
        System.out.printf("\nJPanel's layout manager is %s\n", myPanel.getLayout());
        System.out.printf("JFrame's layout manager is %s\n\n", this.getContentPane().getLayout());
    }
}