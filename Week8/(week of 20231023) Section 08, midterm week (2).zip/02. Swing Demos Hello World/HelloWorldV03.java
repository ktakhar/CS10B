// HelloWorldV03: Give the window a size, center it, and tell JVM to exit the program when window is closed
//                Stepwise refinement: move code out of main() into constructor of class that extends JFrame.

import javax.swing.*;

public class HelloWorldV03 {

    private static final String TITLE="Hello World 03";

    public static void main(String [] args) {

        // Construct the window
        MyWindow myWindow = new MyWindow(TITLE);

        // Make it visible
        myWindow.setVisible(true);

        // Nothing else for main() to do.
        System.out.println("Nothing else for main() to do");
    }
}



// "extends JFrame" is like saying "I'm a window."
class MyWindow extends JFrame {

    private static final int WIDTH=300, HEIGHT=200;

    // The actual creation of the window happens in the class's constructor
    public MyWindow(String title) {

        //this.setTitle(title);
        super(title);

        // Resize the window.
        this.setSize(WIDTH, HEIGHT);

        // Center the windows
        this.setLocationRelativeTo(null); // Centers the window

        // Tell the jvm to kill the program when the window closes.
        // WHAT HAPPENS IF WE COMMENT THIS OUT?
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Construct a label widget
        JLabel myLabel = new JLabel(title);

        // Add the label widget to the window.
        this.add(myLabel);

        // Let's see which layout Manager is being used.
        System.out.printf("\nJFrame's layout manager is %s\n\n", this.getLayout());
    }
}