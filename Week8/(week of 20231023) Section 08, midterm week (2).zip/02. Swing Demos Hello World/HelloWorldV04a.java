// HelloWorldV04a: Illustrate a BorderLayout. Traditional names for regions.

import javax.swing.*;
import java.awt.*;

public class HelloWorldV04a {

    private static final String TITLE="Hello World 04a";

    public static void main(String [] args) {

        // Construct the window
        MyWindow myWindow = new MyWindow(TITLE);

        // Make it visible
        myWindow.setVisible(true);

        // Nothing else for main() to do.
        System.out.println("Nothing else for main() to do");
    }
}



// "extends JFrame" is like saying "I'm a window."
class MyWindow extends JFrame {

    private static final int WIDTH=300, HEIGHT=200;
    private JLabel myLabel1 = new JLabel("North"),
                   myLabel2 = new JLabel("South"),
                   myLabel3 = new JLabel("East"),
                   myLabel4 = new JLabel("West"),
                   myLabel5 = new JLabel("Center");

    // The actual creation of the window happens in the class's constructor
    public MyWindow(String title) {

        this.setTitle(title);

        // Attach a BorderLayout layout manager
        this.setLayout(new BorderLayout());

        // Add widget borders
        myLabel1.setBorder(BorderFactory.createLineBorder(Color.black));
        myLabel2.setBorder(BorderFactory.createLineBorder(Color.black));
        myLabel3.setBorder(BorderFactory.createLineBorder(Color.black));
        myLabel4.setBorder(BorderFactory.createLineBorder(Color.black));
        myLabel5.setBorder(BorderFactory.createLineBorder(Color.black));

        // Add the label widgets to the window. You'll see that with the BorderLayout, the "edge" regions are only as tall or as
        // wide as they need to be to hold their contents. When the window is resized, the only region that changes size is the
        // CENTER region.

        this.add(myLabel1, BorderLayout.NORTH);
        this.add(myLabel2, BorderLayout.SOUTH);
        this.add(myLabel4, BorderLayout.WEST);
        this.add(myLabel3, BorderLayout.EAST);
        this.add(myLabel5, BorderLayout.CENTER);

        // Resize the window.
        this.setSize(WIDTH, HEIGHT);

        // Center the windows
        this.setLocationRelativeTo(null); // Centers the window

        // Tell the jvm to kill the program when the window closes.
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Let's see which layout Manager is being used.
        System.out.printf("\nJFrame's layout manager is %s\n\n", this.getContentPane().getLayout());
    }
}