// HelloWorldV04b: Illustrate a BorderLayout. Alternate names for regions.

import javax.swing.*;
import java.awt.*;

public class HelloWorldV04b {

    private static final String TITLE="Hello World 04b";

    public static void main(String [] args) {

        // Construct the window
        MyWindow myWindow = new MyWindow(TITLE);

        // Make it visible
        myWindow.setVisible(true);

        // Nothing else for main() to do.
        System.out.println("Nothing else for main() to do");
    }
}



// "extends JFrame" is like saying "I'm a window."
class MyWindow extends JFrame {

    private static final int WIDTH=300, HEIGHT=200;
    private JLabel myLabel1 = new JLabel("Page Start"),
                   myLabel2 = new JLabel("Page End"),
                   myLabel3 = new JLabel("Line End"),
                   myLabel4 = new JLabel("Line Start"),
                   myLabel5 = new JLabel("Center");

    // The actual creation of the window happens in the class's constructor
    public MyWindow(String title) {

        this.setTitle(title);

        // Attach a BorderLayout layout manager
        this.setLayout(new BorderLayout());

        // Add widget borders
        myLabel1.setBorder(BorderFactory.createLineBorder(Color.black));
        myLabel2.setBorder(BorderFactory.createLineBorder(Color.black));
        myLabel3.setBorder(BorderFactory.createLineBorder(Color.black));
        myLabel4.setBorder(BorderFactory.createLineBorder(Color.black));
        myLabel5.setBorder(BorderFactory.createLineBorder(Color.black));

        // Add the label widgets to the window. You'll see that with the BorderLayout, the "edge" regions are only as tall or as
        // wide as they need to be to hold their contents. When the window is resized, the only region that changes size is the
        // CENTER region.

        this.add(myLabel1, BorderLayout.PAGE_START);
        this.add(myLabel2, BorderLayout.PAGE_END);
        this.add(myLabel4, BorderLayout.LINE_START);
        this.add(myLabel3, BorderLayout.LINE_END);
        this.add(myLabel5, BorderLayout.CENTER);

        // Resize the window.
        this.setSize(WIDTH, HEIGHT);

        // Center the windows
        this.setLocationRelativeTo(null); // Centers the window

        // Tell the jvm to kill the program when the window closes.
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Let's see which layout Manager is being used.
        System.out.printf("\nJFrame's layout manager is %s\n\n", this.getContentPane().getLayout());
    }
}