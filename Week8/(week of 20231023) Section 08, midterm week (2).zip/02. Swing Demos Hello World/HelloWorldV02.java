// HelloWorldV02: Give the window a size, center it, and tell JVM to exit the program when window is closed

import javax.swing.*;

public class HelloWorldV02 {

    private static final String TITLE="Hello World 02";
    private static final int WIDTH=300, HEIGHT=200;

    public static void main(String [] args) {

        // Construct a window
        JFrame myWindow = new JFrame(TITLE);

        // Resize the window.
        myWindow.setSize(WIDTH, HEIGHT);

        // Center the windows
        myWindow.setLocationRelativeTo(null); // Centers the window

        // Tell the jvm to kill the program when the window closes.
        // WHAT HAPPENS IF WE COMMENT THIS OUT?
        myWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Construct a label widget
        JLabel myLabel = new JLabel(TITLE);

        // Add the label widget to the window.
        myWindow.add(myLabel);

        // Make it visible.
        myWindow.setVisible(true);

        // Let's see which layout Manager is being used.
        System.out.printf("\nJFrame's layout manager is %s\n\n", myWindow.getLayout());

        // Nothing else for main() to do.
        System.out.println("Nothing else for main() to do");
    }
}
