// HelloWorldV07: Show a BorderLayout using a nested JPanel container.
//                By populating the center region with a JPanel that's
//                using a FlowLayout, we can get multiple widgets in
//                the center region.

import javax.swing.*;
import java.awt.*;

public class HelloWorldV07 {

    private static final String TITLE="Hello World 07";

    public static void main(String [] args) {

        // Construct the window
        MyWindow myWindow = new MyWindow(TITLE);

        // Make it visible
        myWindow.setVisible(true);

        // Nothing else for main() to do.
        System.out.println("Nothing else for main() to do");
    }
}



// "extends JFrame" is like saying "I'm a window."
class MyWindow extends JFrame {

    private static final int WIDTH=300, HEIGHT=200;
    private JLabel myLabel1 = new JLabel("North"),
                   myLabel2 = new JLabel("South"),
                   myLabel3 = new JLabel("West"),
                   myLabel4 = new JLabel("East"),
                   myLabel5 = new JLabel("Center1"),
                   myLabel6 = new JLabel("Center2");
    private JPanel myPanel = new JPanel();

    // The actual creation of the window happens in the class's constructor
    public MyWindow(String title) {

        this.setTitle(title);

        // Attach a BorderLayout layout manager.
        this.setLayout(new BorderLayout());

        // Create widget borders
        myLabel1.setBorder(BorderFactory.createLineBorder(Color.black));
        myLabel2.setBorder(BorderFactory.createLineBorder(Color.black));
        myLabel3.setBorder(BorderFactory.createLineBorder(Color.black));
        myLabel4.setBorder(BorderFactory.createLineBorder(Color.black));
        myLabel5.setBorder(BorderFactory.createLineBorder(Color.black));
        myLabel6.setBorder(BorderFactory.createLineBorder(Color.black));

        // Unlike a JFrame, the JPanel uses the FlowLayout by default.
        myPanel.add(myLabel5);
        myPanel.add(myLabel6);
        myPanel.setBorder(BorderFactory.createLineBorder(Color.red));

        this.add(myLabel1, BorderLayout.NORTH);
        this.add(myLabel2, BorderLayout.SOUTH);
        this.add(myLabel3, BorderLayout.WEST);
        this.add(myLabel4, BorderLayout.EAST);
        this.add(myPanel, BorderLayout.CENTER);

        // Resize the window.
        this.setSize(WIDTH, HEIGHT);

        // Center the windows
        this.setLocationRelativeTo(null); // Centers the window

        // Tell the jvm to kill the program when the window closes.
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Let's see which layout Manager is being used.
        System.out.printf("\nJPanel's layout manager is %s\n", myPanel.getLayout());
        System.out.printf("JFrame's layout manager is %s\n\n", this.getContentPane().getLayout());
    }
}