// HelloWorldV08: Use a GridLayout.

import javax.swing.*;
import java.awt.*;

public class HelloWorldV08 {

    private static final String TITLE="Hello World 08";

    public static void main(String [] args) {

        // Construct the window
        MyWindow myWindow = new MyWindow(TITLE);

        // Make it visible
        myWindow.setVisible(true);

        // Nothing else for main() to do.
        System.out.println("Nothing else for main() to do");
    }
}



// "extends JFrame" is like saying "I'm a window."
class MyWindow extends JFrame {

    private static final int WIDTH=300, HEIGHT=200;
    private JLabel myLabel1  = new JLabel("Label one"),
                   myLabel2  = new JLabel("Label two"),
                   myLabel3  = new JLabel("Label three"),
                   myLabel4  = new JLabel("Label four"),
                   myLabel5  = new JLabel("Label five"),
                   myLabel6  = new JLabel("Label six"),
                   myLabel7  = new JLabel("Label seven"),
                   myLabel8  = new JLabel("Label eight"),
                   myLabel9  = new JLabel("Label nine"),
                   myLabel10 = new JLabel("Label ten"),
                   myLabel11 = new JLabel("Label eleven"),
                   myLabel12 = new JLabel("Label twelve");

    // The actual creation of the window happens in the class's constructor
    public MyWindow(String title) {

        this.setTitle(title);

        // Attach a GridLayout layout manager.
        this.setLayout(new GridLayout(3, 4));    // three rows, four columns

        // Add the label widgets to the window. With a grid layout, widgets
        // are added left to right, row by row (top to bottom).
        this.add(myLabel1);     // row 1, column 1
        this.add(myLabel2);     // row 1, column 2
        this.add(myLabel3);     // row 1, column 3
        this.add(myLabel4);     // row 1, column 4
        this.add(myLabel5);     // row 2, column 1
        this.add(myLabel6);     // row 2, column 2
        this.add(myLabel7);     // row 2, column 3
        this.add(myLabel8);     // row 2, column 4
        this.add(myLabel9);     // row 3, column 1
        this.add(myLabel10);    // row 3, column 2
        this.add(myLabel11);    // row 3, column 3
        this.add(myLabel12);    // row 3, column 4

        // Resize the window.
        this.setSize(WIDTH, HEIGHT);

        // Center the windows
        this.setLocationRelativeTo(null); // Centers the window

        // Tell the jvm to kill the program when the window closes.
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Let's see which layout Manager is being used.
        System.out.printf("JFrame's layout manager is %s\n\n", this.getContentPane().getLayout());
    }
}